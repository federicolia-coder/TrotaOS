#!/bin/sh
# Installa Trota VR su un Trota OS 1.0 già installato.
#   sh installa.sh
set -eu
cd "$(dirname "$0")"

ver="$(dpkg-query -W -f='${Version}' trota-common 2>/dev/null || true)"
if [ "$ver" != "1.0.1" ]; then
    echo "Questo pacchetto è per Trota OS 1.0 (trota-common 1.0.1); qui c'è '${ver:-niente}'." >&2
    exit 1
fi

echo "1/3  Aggiorno le librerie Trota (traduzioni) e l'icona di Trota VR"
sudo dpkg -i ./trota-common_1.0.1_all.deb ./trota-artwork_1.0.1_all.deb

echo "2/3  Scarico l'elenco dei pacchetti"
sudo apt-get update

echo "3/3  Installo Trota VR, Monado (OpenXR) e le regole per visori e controller"
sudo apt-get install -y ./trota-vr_1.0.1_all.deb \
    monado-service libopenxr1-monado libopenxr-loader1 xr-hardware steam-devices

echo
echo "Fatto. Apri \"Trota VR\" dalle applicazioni, oppure da terminale: trota-vr --text"
echo "Se il visore era già collegato, scollegalo e ricollegalo."
